package social.service;


import java.util.List;

import social.bean.RestaurantTypeBean;

public interface RestaurantType {

	List<RestaurantTypeBean> queryRestaurantTypes();

}