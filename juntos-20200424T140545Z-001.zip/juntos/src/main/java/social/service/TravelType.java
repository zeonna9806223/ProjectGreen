package social.service;


import java.util.List;

import social.bean.TravelTypeBean;

public interface TravelType {

	List<TravelTypeBean> queryTravelTypes();

}