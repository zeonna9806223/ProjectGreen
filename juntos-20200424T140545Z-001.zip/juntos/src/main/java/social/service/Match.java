package social.service;

import java.util.List;

import social.bean.MatchRequestBean;
import social.bean.MatchesBean;
import social.bean.MatchingBean;

public interface Match {

	void insertMatchRequest(MatchRequestBean mrb);

	List<MatchingBean> todayRequest();
	
	 List getMatch(List<MatchingBean> todayRequest);

	 void insertMatchResult(List<List<Integer>> matchResult);
	
	 void markMatch(List<List<Integer>> matchResult);
	
	List<MatchesBean> showFriend();
}
