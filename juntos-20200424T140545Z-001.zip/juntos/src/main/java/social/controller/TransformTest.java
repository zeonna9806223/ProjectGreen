package social.controller;

public class TransformTest {

	public static void main(String[] args) {
		String s;
		s = "";
		int i;
		Integer in=null;
//		i = Integer.valueOf(s);
		i=in;
		System.out.println(i);
		
	}

}
