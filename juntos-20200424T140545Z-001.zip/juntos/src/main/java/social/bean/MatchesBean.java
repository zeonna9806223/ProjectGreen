package social.bean;

import java.util.Date;

public class MatchesBean {
	private Integer PairId;
	private Integer MemberId1;
	private Integer MemberId2;
	private Integer Friends1;
	private Integer Friends2;
	private Date PairDate;
	private Date FriendDate;
	private Integer Delete1;
	private Integer Delete2;
	
	public MatchesBean() {
		super();
	}

	public MatchesBean(Integer pairId, Integer memberId1, Integer memberId2, Integer friends1, Integer friends2,
			Date pairDate, Date friendDate, Integer delete1, Integer delete2) {
		super();
		PairId = pairId;
		MemberId1 = memberId1;
		MemberId2 = memberId2;
		Friends1 = friends1;
		Friends2 = friends2;
		PairDate = pairDate;
		FriendDate = friendDate;
		Delete1 = delete1;
		Delete2 = delete2;
	}

	public Integer getPairId() {
		return PairId;
	}

	public void setPairId(Integer pairId) {
		PairId = pairId;
	}

	public Integer getMemberId1() {
		return MemberId1;
	}

	public void setMemberId1(Integer memberId1) {
		MemberId1 = memberId1;
	}

	public Integer getMemberId2() {
		return MemberId2;
	}

	public void setMemberId2(Integer memberId2) {
		MemberId2 = memberId2;
	}

	public Integer getFriends1() {
		return Friends1;
	}

	public void setFriends1(Integer friends1) {
		Friends1 = friends1;
	}

	public Integer getFriends2() {
		return Friends2;
	}

	public void setFriends2(Integer friends2) {
		Friends2 = friends2;
	}

	public Date getPairDate() {
		return PairDate;
	}

	public void setPairDate(Date pairDate) {
		PairDate = pairDate;
	}

	public Date getFriendDate() {
		return FriendDate;
	}

	public void setFriendDate(Date friendDate) {
		FriendDate = friendDate;
	}

	public Integer getDelete1() {
		return Delete1;
	}

	public void setDelete1(Integer delete1) {
		Delete1 = delete1;
	}

	public Integer getDelete2() {
		return Delete2;
	}

	public void setDelete2(Integer delete2) {
		Delete2 = delete2;
	}

}
