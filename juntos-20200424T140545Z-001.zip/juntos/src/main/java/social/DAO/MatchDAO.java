package social.DAO;

import java.util.List;

import social.bean.MatchRequestBean;
import social.bean.MatchesBean;
import social.bean.MatchingBean;

public interface MatchDAO {

	void insertMatchRequest(MatchRequestBean mrb);

	List<MatchingBean> todayRequest();

	void insertMatchResult(List<List<Integer>> matchResult);

	void markMatch(List<List<Integer>> matchResult);
	
	List<MatchesBean> showFriend();
}
